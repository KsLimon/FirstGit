import javax.swing.JFrame;
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;

public class Search extends JFrame {
	
	private JLabel ul, ul1, ul2, ul3, ul4, ul5, ul6, ul7;
	private JTextField tf;
	private JButton btn, btn1;
	private Container c;
	private ImageIcon im;
	private Font f, f1, f2;
	
	Search(){
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500,200,780,690);
		this.setTitle("North South University");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.WHITE);
		
		im= new ImageIcon(getClass().getResource("nsu.jpg"));
		this.setIconImage(im.getImage());
		
		f=new Font("Arial",Font.ITALIC, 20);
		ul = new JLabel("Center of Excellence in Higher Education");
		ul.setForeground(Color.BLUE);
		ul.setBounds(190,10,400,50);
		c.add(ul);
		ul.setFont(f);
		
		f1=new Font("Arial",Font.BOLD, 18);
		ul1 = new JLabel("Student ID");
		ul1.setForeground(Color.PINK);
		ul1.setBounds(60,100,100,30);
		c.add(ul1);
		ul1.setFont(f1);
		
		f2=new Font("Arial",Font.BOLD, 16);
		tf = new JTextField("");
		tf.setBackground(Color.white);
		tf.setBounds(200,100, 160, 30);
		c.add(tf);
		tf.setFont(f2);
		
		btn = new JButton("Search");
		btn.setBounds(500,103,170,25);
		btn.setFont(new Font("Arial", Font.ITALIC, 22));
		btn.setBackground(Color.pink);
		c.add(btn);
		
		btn1 = new JButton("Clear");
		btn1.setBounds(500,600,170,25);
		btn1.setBackground(Color.BLACK);
	    btn1.setForeground(Color.PINK);
		c.add(btn1);
		btn1.setFont(f2);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				ul2.setText("");
				ul3.setText("");
				ul4.setText("");
				ul5.setText("");
				ul6.setText("");
				ul7.setText("");
				tf.setText("");
			}
		});
		
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
	
				String id = tf.getText().toString();
				try {
					String path = "C:\\\\Users\\\\Lenovo\\\\Desktop\\\\new/Ks.txt";
					
					FileReader fr = new FileReader(path);
		            BufferedReader br = new BufferedReader(fr);
		            
		            String line, ID, n, d, c1, a, p;
		            boolean isLoginSuccess = false;
		            
		            while ((line = br.readLine()) != null) {
		        
		            	n = line.split(" ")[0];
		                ID = line.split(" ")[1];
		                d = line.split(" ")[2];
		                c1 = line.split(" ")[3];
		                a = line.split(" ")[4];
		                p = line.split(" ")[5];
		                        
		                if (ID.equals(id)) {
		                    isLoginSuccess = true;
		                    
		                    ul2 = new JLabel("Name :  "+n);
		            		ul2.setBounds(60,250,240,30);
		            		ul2.setForeground(Color.DARK_GRAY);
		            		c.add(ul2);
		            		ul2.setFont(f1);
		                    
		            		ul3 = new JLabel("ID :  "+ID);
		            		ul3.setBounds(60,350,240,30);
		            		ul3.setForeground(Color.DARK_GRAY);
		            		c.add(ul3);
		            		ul3.setFont(f1);
		            		
		            		ul4 = new JLabel("Department :  "+d);
		            		ul4.setBounds(60,450,240,30);
		            		ul4.setForeground(Color.DARK_GRAY);
		            		c.add(ul4);
		            		ul4.setFont(f1);
		            		
		            		ul5 = new JLabel("Contuct :  "+c1);
		            		ul5.setBounds(400,250,240,30);
		            		ul5.setForeground(Color.DARK_GRAY);
		            		c.add(ul5);
		            		ul5.setFont(f1);
		            		
		            		ul6 = new JLabel("Program :  "+p);
		            		ul6.setBounds(400,350,240,30);
		            		c.add(ul6);
		            		ul6.setForeground(Color.DARK_GRAY);
		            		ul6.setFont(f1);
		            		
		            		ul7 = new JLabel("Address :  "+a);
		            		ul7.setBounds(400,450,240,30);
		            		ul7.setForeground(Color.DARK_GRAY);
		            		c.add(ul7);
		            		ul7.setFont(f1);
		            		
		    				break;
		                } 
		            }
		            if (!isLoginSuccess) {
		            	JOptionPane.showMessageDialog(null,"Id not match");
		            }
		            fr.close();
					
				}
				catch (Exception ep) {
		            ep.printStackTrace();
		        }
			}
		});
	}
	public static void main (String [] args) {
		Search se= new Search();
		se.setVisible(true);
	}
}
