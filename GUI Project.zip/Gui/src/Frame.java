import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.FileReader;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

public class Frame extends JFrame {
	
	private JLabel ul, ul1, ul2, ul3;
	private JTextField tf;
	private JPasswordField pf;
	private JButton logb;
	private Container c;
	private ImageIcon im;
	private Font f, f1, f2, f3, f4;
	public JFrame frame;
	
	Frame (){
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(700,300,500,400);
		this.setTitle("North South University");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.cyan);
		
		im= new ImageIcon(getClass().getResource("nsu.jpg"));
		this.setIconImage(im.getImage());
		
		f=new Font("Arial",Font.BOLD, 30);
		ul = new JLabel("RDS");
		ul.setBounds(30,0,150,50);
		c.add(ul);
		ul.setFont(f);
		
		f1=new Font("Arial",Font.ITALIC, 20);
		ul1= new JLabel("Enter your information");
		ul1.setBounds(175, 60, 350, 50);
		c.add(ul1);
		ul1.setFont(f1);
		
		ul2= new JLabel("Name:");
		ul2.setBounds(120, 110, 150, 50);
		c.add(ul2);
		ul2.setFont(f1);
		
		ul3= new JLabel("ID:");
		ul3.setBounds(153, 170, 150, 50);
		c.add(ul3);
		ul3.setFont(f1);
		
		f2=new Font("Arial",Font.BOLD, 15);
		tf = new JTextField("");
		tf.setBounds(200, 110, 150, 50);
		c.add(tf);
		tf.setFont(f2);
		
		pf = new JPasswordField("");
		f4=new Font("Arial",Font.BOLD, 20);
		pf.setBounds(200, 170, 150, 50);
		pf.setEchoChar('#');
		c.add(pf);
		pf.setFont(f4);
		
		f3=new Font("Arial",Font.BOLD, 18);
		logb = new JButton("Login");
		logb.setBounds(220, 240, 90, 40);
		c.add(logb);
		logb.setFont(f3);
		
		
		logb.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name = tf.getText().toString();
				String pass = pf.getText().toString();
				try {
					String path = "C:\\\\Users\\\\Lenovo\\\\Desktop\\\\new/User.txt";
					
					FileReader fr = new FileReader(path);
		            BufferedReader br = new BufferedReader(fr);
		            
		            String line, fuser, fpass;
		            boolean isLoginSuccess = false;
		            
		            while ((line = br.readLine()) != null) {
		            	
		                fuser = line.split(" ")[0];
		                fpass = line.split(" ")[1];
		                
		                
		                if (fuser.equals(name) && fpass.equals(pass)) {
		                    isLoginSuccess = true;
		                    
		                    Profile dash = new Profile(name);
		    				dash.Dashframe.setVisible(true);
		    				frame.setVisible(false);
		                    
		    				break;
		                } 
		            }
		            if (!isLoginSuccess) {
		                JOptionPane.showMessageDialog(null, "USERNAME or User Id WRONG", "WARNING!!", JOptionPane.WARNING_MESSAGE);
		            }
		            fr.close();
					
				}
				catch (Exception ep) {
		            ep.printStackTrace();
		        }
				
			}
		});
		
	}
	
	public static void main (String [] args) {
		Frame f= new Frame();
		f.setVisible(true);
	}

}