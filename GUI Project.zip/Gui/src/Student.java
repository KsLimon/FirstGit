import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class Student extends JFrame implements ActionListener {
	
	private JTable table;
	private JScrollPane scroll;
	private DefaultTableModel model;
	private JLabel ul, ul1, ul2, ul3, ul4, ul5, ul6;
	private JTextField tf, tf1, tf2, tf3, tf4, tf5;
	private JButton abtn, ubtn, dbtn, cbtn;
	private Container c;
	private ImageIcon im;
	private Font f, f1, f2, f3;
	
	private String[] column= {"Name", "Stdent ID", "Department", "Contuct", "Address", "Program"};
	private String[] row= new String[6];
	
	Student(){
		
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setBounds(500,200,780,690);
		this.setTitle("North South University");
		
		c=this.getContentPane();
		c.setLayout(null);
		c.setBackground(Color.pink);
		
		im= new ImageIcon(getClass().getResource("nsu.jpg"));
		this.setIconImage(im.getImage());
		
		f=new Font("Arial",Font.ITALIC, 20);
		ul = new JLabel("Student Management");
		ul.setForeground(Color.BLACK);
		ul.setBounds(290,10,250,50);
		c.add(ul);
		ul.setFont(f);
		
		f1=new Font("Arial",Font.BOLD, 17);
		ul1 = new JLabel("Name");
		ul1.setBounds(40,80,140,30);
		c.add(ul1);
		ul1.setFont(f1);
		
		f2=new Font("Arial",Font.BOLD, 16);
		tf = new JTextField("");
		tf.setBackground(Color.pink);
		tf.setBounds(40, 105, 160, 30);
		c.add(tf);
		tf.setFont(f2);
		
		ul2 = new JLabel("Department");
		ul2.setBounds(40,145,140,30);
		c.add(ul2);
		ul2.setFont(f1);
		
		tf1 = new JTextField("");
		tf1.setBounds(40, 170, 160, 30);
		tf1.setBackground(Color.pink);
		c.add(tf1);
		tf1.setFont(f2);
		
		ul3 = new JLabel("Contact");
		ul3.setBounds(40,210,140,30);
		c.add(ul3);
		ul3.setFont(f1);
		
		tf2 = new JTextField("");
		tf2.setBounds(40, 235, 160, 30);
		tf2.setBackground(Color.pink);
		c.add(tf2);
		tf2.setFont(f2);
		
		ul4 = new JLabel("Student ID");
		ul4.setBounds(240,80,140,30);
		c.add(ul4);
		ul4.setFont(f1);
		
		tf3 = new JTextField("");
		tf3.setBackground(Color.pink);
		tf3.setBounds(240, 105, 160, 30);
		c.add(tf3);
		tf3.setFont(f2);
		
		ul5 = new JLabel("Program");
		ul5.setBounds(240,145,140,30);
		c.add(ul5);
		ul5.setFont(f1);
		
		tf4 = new JTextField("");
		tf4.setBackground(Color.pink);
		tf4.setBounds(240, 170, 160, 30);
		c.add(tf4);
		tf4.setFont(f2);
		
		ul6 = new JLabel("Address");
		ul6.setBounds(240,210,140,30);
		c.add(ul6);
		ul6.setFont(f1);
		
		tf5 = new JTextField("");
		tf5.setBackground(Color.pink);
		tf5.setBounds(240, 235, 160, 30);
		c.add(tf5);
		tf5.setFont(f2);
		
		f3=new Font("Arial",Font.BOLD, 18);
		abtn = new JButton("Add");
		abtn.setBounds(525, 103, 100, 30);
		abtn.setBackground(Color.black);
		abtn.setForeground(Color.PINK);
		c.add(abtn);
		abtn.setFont(f3);
		
		ubtn = new JButton("Update");
		ubtn.setBounds(450, 168, 100, 30);
		ubtn.setBackground(Color.BLACK);
		ubtn.setForeground(Color.PINK);
		c.add(ubtn);
		ubtn.setFont(f3);
		
		dbtn = new JButton("Delete");
		dbtn.setBounds(600, 168, 100, 30);
		dbtn.setBackground(Color.BLACK);
		dbtn.setForeground(Color.PINK);
		c.add(dbtn);
		dbtn.setFont(f3);
		
		cbtn = new JButton("Clear");
		cbtn.setBounds(525, 233, 100, 30);
		cbtn.setBackground(Color.BLACK);
		cbtn.setForeground(Color.PINK);
		c.add(cbtn);
		cbtn.setFont(f3);
		
		table= new JTable();
		
		model= new DefaultTableModel();
		model.setColumnIdentifiers(column);
		table.setModel(model);
		table.setFont(f2);
		table.setSelectionBackground(Color.RED);
		table.setBackground(Color.LIGHT_GRAY);
		table.setRowHeight(30);
		
		scroll= new JScrollPane(table);
		scroll.setBounds(11, 350, 740, 265);
		c.add(scroll);
		
		abtn.addActionListener(this);
		cbtn.addActionListener(this);
		dbtn.addActionListener(this);
		ubtn.addActionListener(this);
		
		table.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent ae) {
			int nrow= table.getSelectedRow();
			
			String n=model.getValueAt(nrow, 0).toString();
			String d=model.getValueAt(nrow, 1).toString();
			String b=model.getValueAt(nrow, 2).toString();
			String c=model.getValueAt(nrow, 3).toString();
			String a=model.getValueAt(nrow, 4).toString();
			String p=model.getValueAt(nrow, 5).toString();
			
			tf.setText(n);
			tf3.setText(d);
			tf1.setText(b);
			tf2.setText(c);
			tf5.setText(a);
			tf4.setText(p);
			}
		});
	}
	@Override
	public void actionPerformed(ActionEvent a) {
	
		if (a.getSource()==abtn) {
			row[0]=tf.getText();
			row[1]=tf3.getText();
			row[2]=tf1.getText();
			row[3]=tf2.getText();
			row[4]=tf5.getText();
			row[5]=tf4.getText();
			model.addRow(row);
			
			try {
				  String path = "C:\\Users\\Lenovo\\Desktop\\new/Ks.txt";
			      FileWriter myWriter = new FileWriter("C:\\Users\\Lenovo\\Desktop\\new/Ks.txt",true);
			      myWriter.write(tf.getText()+" "+tf3.getText()+" "+tf1.getText()+" "+tf2.getText()+" "+tf5.getText()+" "+tf4.getText()+"\n");
			      myWriter.close();
			    } 
			catch (IOException ep) {
			      System.out.println("ERROR 404!");
			      ep.printStackTrace();
			    }
		}
		else if (a.getSource()==cbtn) {
			tf.setText("");
			tf1.setText("");
			tf2.setText("");
			tf3.setText("");
			tf4.setText("");
			tf5.setText("");
			
		}
        else if (a.getSource()==dbtn) {
			int nrow= table.getSelectedRow();
			
			if (nrow>=0) {
				model.removeRow(nrow);
				
			}
			else
				JOptionPane.showMessageDialog(null, "No row has been selected");
		}
        else if (a.getSource()==ubtn) {
			int nrow= table.getSelectedRow();
			
			String n=tf.getText();
			String d=tf3.getText();
			String b=tf1.getText();
			String c=tf2.getText();
			String ad=tf5.getText();
			String p=tf4.getText();
			
			model.setValueAt(n, nrow, 0);
			model.setValueAt(d, nrow, 1);
			model.setValueAt(b, nrow, 2);
			model.setValueAt(c, nrow, 3);
			model.setValueAt(ad, nrow, 4);
			model.setValueAt(p, nrow, 5);
        }
	}
	
	public static void main (String [] args) {
		Student s= new Student();
		s.setVisible(true);
	}
}
