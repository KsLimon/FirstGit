import java.awt.EventQueue;
import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Profile extends JFrame{

	public JFrame Dashframe;
	public String Username;
	private ImageIcon im, i;
	private JLabel ul;
	private JButton btn, btn1, btn2, btn3, btn4;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Profile window = new Profile("null");
					window.Dashframe.setVisible(true);
					
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	public Profile(String name) {
		
		Username= name;
		initialize();
	}
	
		public void initialize() {
		Dashframe = new JFrame("Welcome, "+Username);
		Dashframe.getContentPane().setFont(new Font("Georgia", Font.BOLD, 14));
		Dashframe.getContentPane().setLayout(null);
		Dashframe.getContentPane().setBackground(Color.cyan);
		
		im= new ImageIcon(getClass().getResource("nsu.jpg"));
		Dashframe.setIconImage(im.getImage());
		Dashframe.setBounds(700,300,500,400);
		Dashframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		i= new ImageIcon(getClass().getResource("cap.jpg"));
		ul= new JLabel (i);
		ul.setBounds(30,80,200,200);
		Dashframe.getContentPane().add(ul);
		
		btn = new JButton("Home");
		btn.setBounds(30,10,100,18);
		btn.setFont(new Font("Arial", Font.BOLD, 22));
		btn.setBackground(Color.DARK_GRAY);
		btn.setForeground(Color.CYAN);
		Dashframe.getContentPane().add(btn);
		btn.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dashframe.setVisible(false);
				Frame l = new Frame();
				l.frame.setVisible(true);
			}
		});
		
		btn1 = new JButton("Student");
		btn1.setBounds(250,95,150,40);
		btn1.setFont(new Font("Arial", Font.BOLD, 22));
		btn1.setBackground(Color.pink);
		Dashframe.getContentPane().add(btn1);
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dashframe.setVisible(false);
				Student l = new Student();
				l.setVisible(true);
			}
		});
		
		btn2 = new JButton("Faculty");
		btn2.setBounds(250,145,150,40);
		btn2.setFont(new Font("Arial", Font.BOLD, 22));
		btn2.setBackground(Color.orange);
		Dashframe.getContentPane().add(btn2);
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dashframe.setVisible(false);
				Frame l = new Frame();
				l.frame.setVisible(true);
			}
		});
		
		btn3 = new JButton("Register");
		btn3.setBounds(250,195,150,40);
		btn3.setFont(new Font("Arial", Font.BOLD, 22));
		btn3.setBackground(Color.YELLOW);
		Dashframe.getContentPane().add(btn3);
		btn3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dashframe.setVisible(false);
				Frame l = new Frame();
				l.frame.setVisible(true);
			}
		});
		
		btn4 = new JButton("Search");
		btn4.setBounds(160,300,170,25);
		btn4.setFont(new Font("Arial", Font.ITALIC, 22));
		btn4.setBackground(Color.lightGray);
		Dashframe.getContentPane().add(btn4);
		btn4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Dashframe.setVisible(false);
				Search l = new Search();
				l.setVisible(true);
			}
		});
	}
}